# alias_notas.sh — Refactor
INSTALL_DIR="$HOME/notas"

if [ ! -d "$INSTALL_DIR" ]; then
    echo "ERROR: No se encuentra el directorio $INSTALL_DIR"
    return 1
fi

declare -A alias_map=(
  ["alerta_horaria"]="alerta_horaria.sh"
  ["nota_texto"]="nota_texto.sh"
  ["nota_voz"]="nota_voz.sh"
  ["resumen_dia"]="resumen_dia.sh"
  ["resumen_audio"]="resumen_audio.sh"
  ["resumen_proyecto"]="resumen_proyecto.sh"
  ["sync_backup"]="backup_and_sync.sh"
  ["backup_now"]="daily_backup.sh"
  ["setup_startup"]="setup_startup_service.sh"
  ["alerta_horaria"]="alerta_horaria.sh"
)

for cmd in "${!alias_map[@]}"; do
  script="$INSTALL_DIR/${alias_map[$cmd]}"
  if [ -x "$script" ]; then
    alias "$cmd"="cd $INSTALL_DIR && ./${alias_map[$cmd]}"
  else
    echo "WARNING: Script $script no encontrado o no ejecutable"
  fi
done

# Alias del menú interactivo
alias notas_menu="bash $INSTALL_DIR/notas_menu.sh"
