#!/bin/bash
FECHA=$(date '+%Y-%m-%d')
mkdir -p /home/markmur88/notas/logs/voz/$FECHA
FILENAME="voz_$(date '+%H-%M-%S').wav"
echo "🎙 Grabando 60s... (Ctrl+C para cortar antes)"
arecord -d 60 -f cd -t wav /home/markmur88/notas/logs/voz/$FECHA/$FILENAME
echo "✅ Audio guardado en /home/markmur88/notas/logs/voz/$FECHA/$FILENAME"
