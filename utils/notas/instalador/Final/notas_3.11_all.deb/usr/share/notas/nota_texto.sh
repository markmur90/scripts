#!/bin/bash
FECHA=$(date '+%Y-%m-%d')
HORA=$(date '+%H:%M')
mkdir -p /home/markmur88/notas/logs/texto/$FECHA
echo "📒 Nota rápida (terminá con Ctrl+D):"
cat >> /home/markmur88/notas/logs/texto/$FECHA/nota_texto.txt <<EOF
[$HORA]
$(cat)
EOF
echo "✅ Nota guardada en /home/markmur88/notas/logs/texto/$FECHA/nota_texto.txt"
