#!/bin/bash

echo "[*] Eliminando archivos de instalación..."

INSTALL_DIR="$HOME/notas"
CONFIG_FILE="$HOME/.config/notas_instalador/config.conf"
ALIAS_FILE="$HOME/.alias_notas"
ZSHRC="$HOME/.zshrc"

# Eliminar scripts
rm -rf "$INSTALL_DIR"
rm -f "$CONFIG_FILE"
rm -f "$ALIAS_FILE"

# Limpiar .zshrc
sed -i '/source ~/.alias_notas/d' "$ZSHRC"

# Limpiar tareas del crontab
crontab -l | grep -v "$INSTALL_DIR" | crontab -

echo "[✔] Desinstalación completa. Podés reiniciar la terminal para reflejar cambios."
