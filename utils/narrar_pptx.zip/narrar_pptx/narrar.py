import os
from pptx import Presentation
import boto3
import win32com.client

# Rutas
ppt_path = r"C:\ruta\a\presentacion.pptx"
output_ppt = r"C:\ruta\a\presentacion_narrada.pptx"
audio_folder = r"C:\ruta\a\audios"

# Asegurar carpeta de audios
os.makedirs(audio_folder, exist_ok=True)

# Cliente Polly
polly = boto3.client('polly', region_name='us-east-1')

# Extraer texto y generar audios
prs = Presentation(ppt_path)
for idx, slide in enumerate(prs.slides, start=1):
    text_runs = []
    for shape in slide.shapes:
        if hasattr(shape, "text"):
            text_runs.append(shape.text)
    full_text = "\n".join(text_runs).strip()
    if not full_text:
        continue
    response = polly.synthesize_speech(
        Text=full_text,
        VoiceId='Joanna',
        OutputFormat='mp3',
        Engine='neural'
    )
    audio_path = os.path.join(audio_folder, f"slide{idx}.mp3")
    with open(audio_path, 'wb') as f:
        f.write(response['AudioStream'].read())

# Incrustar audios vía COM
ppt_app = win32com.client.Dispatch("PowerPoint.Application")
ppt_app.Visible = True
presentation = ppt_app.Presentations.Open(ppt_path)

for idx in range(1, len(prs.slides) + 1):
    audio_file = os.path.join(audio_folder, f"slide{idx}.mp3")
    if os.path.exists(audio_file):
        slide = presentation.Slides(idx)
        slide.Shapes.AddMediaObject2(audio_file, False, True, 50, 50)

presentation.SaveAs(output_ppt)
presentation.Close()
ppt_app.Quit()
